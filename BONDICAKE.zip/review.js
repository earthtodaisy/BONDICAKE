/*REVIEWS*/
// Access the testimonials
let testSlide = document.querySelectorAll('.testItem');
// Access the indicators
let dots = document.querySelectorAll('.dot');

var counter = 0;
var deleteInterval; // Declare this variable outside functions

// Add click event to the indicators
function switchTest(currentTest) {
    currentTest.classList.add('active');
    var testId = currentTest.getAttribute('attr');
    if (testId > counter) {
        testSlide[counter].style.animation = 'next1 1s ease forwards';
        counter = testId;
        testSlide[counter].style.animation = 'next2 1s ease forwards';
    } else if (testId == counter) { return; }
    else {
        testSlide[counter].style.animation = 'prev1 1s ease forwards';
        counter = testId;
        testSlide[counter].style.animation = 'prev2 1s ease forwards';
    }
    indicators();
}

// Add and remove active class from the indicators
function indicators() {
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(' active', '');
    }
    dots[counter].className += ' active';
}

// Code for auto sliding
function slideNext() {
    testSlide[counter].style.animation = 'next1 1s ease forwards';
    if (counter >= testSlide.length - 1) {
        counter = 0;
    } else {
        counter++;
    }
    testSlide[counter].style.animation = 'next2 1s ease forwards';
    indicators();
}

// Modify autoSliding function to include a pause
function autoSliding() {
    deleteInterval = setInterval(() => {
        // Pause for 2 seconds before sliding
        setTimeout(() => {
            slideNext();
            indicators();
        }, 2000); // Adjust the time here for the pause duration (2000 ms = 2 seconds)
    }, 4000); // Total interval: pause duration + animation duration
}

// Start auto sliding
autoSliding();

// Stop auto sliding when mouse is over the indicators
const containerr = document.querySelector('.indicators');
containerr.addEventListener('mouseover', pause);
function pause() {
    clearInterval(deleteInterval);
}

// Resume sliding when mouse is out of the indicators
containerr.addEventListener('mouseout', autoSliding);
