function showSection(id) {
    var sections = document.querySelectorAll('.section');
    sections.forEach(function(section) {
        section.classList.remove('active'); 
    });
    document.getElementById(id).classList.add('active');
}

function showSection(sectionId) {
    
    const sections = document.querySelectorAll('.section');

   
    sections.forEach((sec) => {
        sec.classList.remove('active'); 
    });

    
    const activeSection = document.getElementById(sectionId);
    if (activeSection) {
        activeSection.classList.add('active'); 
    }
}

function addToCart(productName) {
    const notification = document.getElementById('notification');
    const message = document.getElementById('notification-message');
    
    message.textContent = `${productName} has been added to your cart!`;
    
    notification.classList.add('show');
    
    setTimeout(() => {
        notification.classList.remove('show');
    }, 3000);
}

